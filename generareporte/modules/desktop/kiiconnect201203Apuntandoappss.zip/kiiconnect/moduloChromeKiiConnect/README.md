Chrome push notifications via Chrome Extension.
=========================

Guide:  
https://www.pushwoosh.com/programming-push-notification/chrome/chrome-extension-notifications/

It is recommended to use Native Chrome push available in the 42 version of Google Chrome.  
https://github.com/Pushwoosh/chrome-push-notifications/tree/master/Browser/
