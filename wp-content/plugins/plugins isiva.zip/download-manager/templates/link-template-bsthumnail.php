<!-- WPDM Link Template: Bootstrap Thumbnail -->
 
<div class="thumbnail col-md-4" style="margin: 0 5px 7px 0;">
    <a href="[page_url]">
    [thumb_350x250]
    </a>
    <div class="caption">
    <h4 class="media-heading" style="padding: 0px;margin:0px">[page_link]</h4>
    <p>
    [file_size] | [download_count] downloads 
    </p> 
    <div class="btn-group">
    [download_link]
    </div>
    </div>
</div> 
 