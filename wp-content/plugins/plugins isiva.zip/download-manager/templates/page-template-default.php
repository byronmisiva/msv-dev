<!-- WPDM Template: Default Template -->
<div class="row">
<div class="col-md-12">

<table class="table">
<tbody>
<tr><td>Version</td><td>[version]</td></tr>
<tr><td>Download</td><td>[download_count]</td></tr>
<tr><td>Stock</td><td>[quota]</td></tr>
<tr><td>Total Files</td><td>[file_count]</td></tr>
<tr><td>File Size</td><td>[file_size]</td></tr>
<tr><td>Create Date</td><td>[create_date]</td></tr>
<tr><td>Last Updated</td><td>[update_date]</td>
</tr>
</tbody></table>

</div>
<div class="col-md-12">
[description]  
 
<br />
<div class="panel panel-default">
    <div class="panel-heading"><b>Download</b></div>
    [file_list]
    <div class="panel-footer text-right">
        [download_link]
    </div>
</div>

<br>

</div> 
</div>


