<!-- WPDM Link Template: Call to Action 1 -->

<blockquote class="light left" style="padding: 20px;border:4px solid #E23F8E !important;border-radius: 6px">
    <div class="media">
            <div class="pull-right" align="right">
                [download_link]
            </div>

                <div class="media-body">
                    <h3 class="media-heading" style="padding-top: 0px;border:0px;margin: 0 0 5px 0;font-size:12pt;"><a style="font-weight: 700" href="[page_url]">[title]</a> <span style="margin-left:30px;font-size:8pt;font-weight:300"><i style="margin: 2px 0 0 5px;opacity:0.5" class="icon icon-th-large"></i> [file_size] <i style="margin: 2px 0 0 5px;opacity:0.5" class="icon icon-download-alt"></i> [download_count] downloads</span></h3>
                    [excerpt_80]
                </div>

    </div>

</blockquote>