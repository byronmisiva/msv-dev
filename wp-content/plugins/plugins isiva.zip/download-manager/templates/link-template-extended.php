<!-- WPDM Link Template: 3 Columns, Detailed -->
<div class="clear"></div>
<div class="row">
<div class="col-md-12">
<div class="thumbnail">
<div class="row">
<div class="col-md-3">
[thumb_300x250]
</div>
<div class="col-md-5">
<a href="[page_url]"><strong>[title]</strong></a><br/>
[excerpt_200]  
<div style="margin-top: 10px;">
[thumb_gallery_40x40]
</div>
</div>
<div class="col-md-4">
<table class="table table-bordered table-striped">
<tbody>
<tr><td>Size</td><td>[file_size]</td></tr>
<tr><td>Downloaded</td><td>[download_count] times</td></tr>
<tr><td>Last Updated</td><td>[update_date]</td></tr>
<tr><td colspan="2">[download_link]</td></tr>
</tbody></table>    
</div> 
</div>
</div>
</div>
</div>
<hr noshade="noshade" size="1" />


