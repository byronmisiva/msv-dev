=== Clone Posts ===
Contributors: lukaszwebmaster
Donate link: 
Tags: clone posts, clone pages, clone post, clone page, clone, page cloning, post cloning, posts cloning, pages cloning, page copy, page copy paste, post copy, posts copy paste, copy pages, copy posts, copy and paste posts, copy and paste pages, clone, cloning, copy and paste
Requires at least: 3.9.1
Tested up to: 3.9.1
Stable tag: 1.0
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Cloning posts and pages in WordPress.

== Description ==

This is a simple plugin that allows you clone (copy and paste) posts and pages in your WordPress.

= Features =

* 	Cloning single post
*	Cloning multiple posts

== Installation ==

1. Uncompress the download package
1. Upload folder including all files the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= Version 1.0 =
* 	initial version

== Screenshots ==

1. Clone single post
2. Clone multiple posts
