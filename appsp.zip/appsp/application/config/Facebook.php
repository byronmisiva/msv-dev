<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	$config = array(
	            'appId'  => '553578624662658',
	            'secret' => '9a606139b1e07ec725016e7867cf559f',
	          );