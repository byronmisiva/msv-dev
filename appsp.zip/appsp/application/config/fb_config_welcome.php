<?php
	$config['facebook_api_id'] = '553578624662658';
	$config['facebook_secret_key'] = '9a606139b1e07ec725016e7867cf559f';
	$config['facebook_namespace'] = 'namespacepruebas';
	//$config['facebook_page'] = 'pages/Misiva-Likepage-Preproduccion/195554460484731';
	$config['facebook_page'] = 'samsungmobilecuador';
	$config['facebook_permissions'] = "email";