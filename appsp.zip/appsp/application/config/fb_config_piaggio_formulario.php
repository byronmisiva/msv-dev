<?php
	$config['facebook_api_id'] = '274414319389630';
	$config['facebook_secret_key'] = '03ac23ed6fa688c4faba471f65699c1a';
	$config['facebook_namespace'] = 'piaggio_formulario';	
	//$config['facebook_page'] = 'pages/Misiva-Likepage-Preproduccion/195554460484731';
	$config['facebook_page'] = 'PiaggioEcuador';
	$config['facebook_permissions'] = "email";