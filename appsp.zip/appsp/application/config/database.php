<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$active_group = 'default';
$active_record = TRUE;

$db['default']['hostname'] = "69.64.85.167";
$db['default']['username'] = "externo";
$db['default']['password'] = "feadmin06";
$db['default']['database'] = "kiiconnect";
$db['default']['dbdriver'] = "mysql";
$db['default']['dbprefix'] = "kiiconnect_";
$db['default']['pconnect'] = TRUE;
$db['default']['db_debug'] = TRUE;
$db['default']['cache_on'] = FALSE;
$db['default']['cachedir'] = "";
$db['default']['char_set'] = "utf8";
$db['default']['dbcollat'] = "utf8_general_ci";