<?php
	$config['facebook_api_id'] = '507382259360517';
	$config['facebook_secret_key'] = '2f48932163b5c7d3b08dd890c2945723';
	$config['facebook_namespace'] = 'samsung_santa';	
	//$config['facebook_page'] = 'pages/Misiva-Likepage-Preproduccion/195554460484731';
	$config['facebook_page'] = 'samsungmobilecuador';
	$config['facebook_permissions'] = "email,publish_actions";