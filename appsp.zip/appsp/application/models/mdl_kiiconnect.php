<?php
class Mdl_kiiconnect extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database('default');
	}
		
	function verificarMessage($id){		
		$this->db->where('id',$id);
		$user=$this->db->get('mensajes');
		if ($user->num_rows()>0)		
			return "1";
		else 
			return "0";
	}	
}