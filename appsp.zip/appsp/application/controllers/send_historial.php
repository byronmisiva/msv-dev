<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Send_historial extends CI_Controller{	
	public $data;
	var $appCode;
	var $autToken;
		
	public function __construct(){
		parent::__construct();
		$this->load->model('mdl_kiiconnect','modelo');
		$this->appCode="34B34-CA8EC";
		$this->autToken="eNYzs32HAKRtn4vatf4ylwEiYItTmp9s/Q+7ppCEoQha1bzYXLx8yVsIpBAG16cH+QiSTKMyuaBCdUbS+efa";
	}
	
	function pwCall($method,$data) {
		$url = 'https://cp.pushwoosh.com/json/1.3/'. $method;
		$request = json_encode($data);
		$this->loadbd($this->doPostRequest($url, $request, 'Content-Type: application/json'));
	}
	
	function loadbd($data){
		$data=json_decode($data);
//echo "Hora: ".date("Y-m-d H:m:s");
echo "<pre>";
var_dump($data);
echo "<pre>";

		$fecha = date('Y-m-d H:i:s');
		$nuevafecha = strtotime ( '5 hour' ) + strtotime ( $fecha )  ;
		$horaServidor = new DateTime(date ( 'Y-m-d H:i:s' , $nuevafecha ));
		//$horaServidor = $nuevafecha;
		$cont=0;
		$rest="";
		foreach ($data->response->rows as $row){
			$rest="";	
			$cont=$cont+1;
			if ($cont<=20){
			$horaPushwoosh = new DateTime(date($row->sendDate));
			$horaServidor->format('U');
			$horaPushwoosh->format('U');			
			if ($horaServidor >= $horaPushwoosh){			
				$total = strlen ( $row->filter ) ;
				if ($total > 0){
					$total=$total-2;
					$rest = substr($row->filter, 8);
					$rest = substr($rest, 0,strlen($rest)-1);
				}else{
				$rest="";
				}

				
				if ($row->url == "" )
					$link=$row->url;
				else
					$link=$row->richPageId;
				
				$insertData=array(
					"body"=>$row->content->es,
					"id"=>$row->id,
					"header"=>$link.";".$rest,
					"l"=>$row->url,
					"tag"=>$rest,
					"header"=>$row->filter
				);
				
echo "<pre>";
	var_dump($insertData);
echo "<pre>";

				/*if ($this->modelo->verificarMessage($row->id) == "0"){					 
					$this->db->insert("kiiconnect_mensajes",$insertData);
				}*/
								
			}

			}


			//echo $row->url." | ".$row->filter." | ".$row->richPageId."<br>";
		}
	}
	
	function doPostRequest($url, $data, $optional_headers = null){
		$params = array(
				'http' => array(
						'method' => 'POST',
						'content' => $data
				));
		if ($optional_headers !== null)
			$params['http']['header'] = $optional_headers;
	
		$ctx = stream_context_create($params);
		$fp = fopen($url, 'rb', false, $ctx);
		if (!$fp)
			throw new Exception("Problem with $url ");
	
		$response = @stream_get_contents($fp);
		if ($response === false)
			return false;
		return $response;
	}
	
	function ejecucion(){
		$this->pwCall('getPushHistory', array(
				"request" => array(
						"auth"=>$this->autToken,
						"source"=>"CP",
						"searchBy"=>"applicationCode",
						"value"=>$this->appCode,
						"lastNotificationID"=>0,
				))
		);
	}


	function ejecucionAuto(){
		$this->pwCall('getPushHistory', array(
				"request" => array(
						"auth"=>$this->autToken,
						"source"=>"AutoPush",
						"searchBy"=>"applicationCode",
						"value"=>$this->appCode,
						"lastNotificationID"=>0,
				))
		);
	}

	function ejecucionGeo(){
		$this->pwCall('getPushHistory', array(
				"request" => array(
						"auth"=>$this->autToken,
						"source"=>"GeoZone",
						"searchBy"=>"applicationCode",
						"value"=>$this->appCode,
						"lastNotificationID"=>0,
				))
		);
	}




	
}
 
