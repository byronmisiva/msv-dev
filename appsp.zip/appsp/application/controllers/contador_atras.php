<?php
class Contador_atras extends Facebook_Controller{
	
	public function __construct(){
		parent::__construct();
	}

	function index(){
			$this->load->view( 'contador/view');
	}
	
}
	