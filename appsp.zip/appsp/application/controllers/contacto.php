<?php
class Contacto extends Facebook_Controller{
	
	public function __construct(){
		parent::__construct();
	}

	function index(){
			$this->load->view( 'contacto/index');
	}
	
	function envio_mail(){		
		$this->load->library('email');
		$config['protocol'] = 'sendmail';
		$config['charset'] = 'utf8';
		$config['mailtype'] = 'html';
		$config['wordwrap'] = FALSE;
		
		$this->email->initialize($config);
		$this->email->from('info@misiva.com.ec','Contacto');
		$this->email->to('ventas@pmjarquitectos.com');		
		$data['informacion']=$_POST;
		$body=$this->load->view( 'contacto/email',$data,TRUE);
		$this->email->subject("Registro Parques Galicia");		
		$this->email->message($body);
		$this->email->send();
		
		echo "1";
	}
	
	
}
	
