<!DOCTYPE html>
<html>
<head>	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />	
	<link href="<?php echo base_url('css/piaggio_formulario/piaggio_formulario.css?refresh='.rand(10, 1000))?>" rel="stylesheet">
	<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no"/>	
</head>
<body style="width: 100%;background: #000000;margin: 0;padding: 0;height: auto;">
	<div class="nolike" style="height:800px;background-repeat:no-repeat; background-image: url('<?=$fondo?>');background-size:100%;height: auto; ">
	
	</div>
</body>
</html>