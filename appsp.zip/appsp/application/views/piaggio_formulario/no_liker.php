<div class="nolike"  style="height:800px;background-repeat:no-repeat; background-image: url('<?php echo $data['fondo']?>');">	 

</div>