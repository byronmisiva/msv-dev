<div class="fondo" style="height:800px;background-repeat:no-repeat; background-image: url('<?php echo $data['fondo']?>');">
	<div class="registro" >
		<form id ="register" method="post" role="form" class="form-horizontal formulario" action="<?php echo base_url('piaggio_formulario/register')?>">
			<div class="form-group">		
				<div class="form-control" style="margin-top: 40px;">
					<input type="text" id="nombre"	name="nombre" placeholder="Nombre" value="<?php echo $data['user']->name;?>" />				
				</div>
			</div>
			<div class="form-group">			
				<div class="form-control" style="margin-top: 31px;">			
					<input type="text"  id="ciudad" name="ciudad" placeholder="Ciudad" value="<?php echo (isset( $data['user']->location )) ? $data['user']->location->name : '';?>" />
				</div>
			</div>
			
			<div class="form-group" style="margin-top: 30px;">			
				<div class="form-control" >
					<input type="text" id="fecha" name="fecha" placeholder="" value="" />
				</div>
			</div>
			
			<div class="form-group" style="margin-top: 32px;">			
				<div class="form-control">
					<input type="text" id="telefono" name="telefono" placeholder="Teléfono" value="<?php echo $data['user']->telefono?>" />
				</div>
			</div>
							
			
			<div class="form-group" style="margin-top: 29px;">			
				<div class="form-control" >
					<input type="text" id="mail" name="mail" placeholder="E-mail" value="<?php echo $data['user']->email?>" />
				</div>
			</div>

			<input type="hidden" name="user" id="user" value='<?php echo json_encode($data['user'])?>'>
			<input type="hidden" name="fb_page" id="fb_page" value='<?php echo json_encode($data['fb_page'])?>'>
			<div class="form-group" style="margin-top: -10px;">
				<input id="submit" name="submit" type="submit" value="" class="btn-sumbit" style="cursor:pointer;margin-left: 150px;width:89px;height:24px;   display: inline-block; margin-top: 32px;background-image: url('<?php echo $data['boton']?>');">
			</div>
		</form>
		<?php foreach ( $data['errors'] as $key => $value ){?>
			<?php if( $value ){?>
				<script type="text/javascript">
					Tab.showErrors('<?php echo $key;?>');
				</script>		
			<?php }?>		
		<?php }?>
		
	</div>
	 <script type="text/javascript">
		$(function() {
		    $( "#fecha" ).datepicker({ 
			    changeYear: true,
			    changeMonth: true,
			    yearRange: "1930:2010",
			    dateFormat: "yy-mm-dd" });
		  });		
		/*Tab.register();*/		
		
	var rules = [ 
				   { name: 'nombre', display: 'nombre', rules: 'required'},
	               { name: 'ciudad', display: 'ciudad', rules: 'required'},
	               { name: 'fecha', display: 'fecha', rules: 'required'},
	               { name: 'telefono', display: 'telefono', rules: 'required|min_length[10]'},	               
	               { name: 'mail', display: 'mail', rules: 'required|valid_email'}	               
	            ];    
	
	var validator = new FormValidator('register',rules, function(errors, event) {		
		 if (errors.length > 0) {
		        var errorString = '';		        
		        /*for (var i = 0, errorLength = errors.length; i < errorLength; i++) {
		            	$('#'+errors[i].id).css("color","#ffffff");	    
		            	      			       
		        }*/
		        alert("Verifica que la información ingresada sea la correcta.");  
		    }else{
		    	enviarForma('<?=base_url()?>','register'); 		    			    	
			    }
		});
	
	
		function enviarForma(accion,forma){						
		$.ajax({  
			  type: "POST",  
			  url: accion+"piaggio_formulario/register",  
			  data: $('#'+forma).serialize(),
			  success: function( response ) {
				  if (response=="1"){					  
					$('#submit').hide();
				    $('#content').load(accion+"piaggio_formulario/gracias");
				  }
	    		} 
			}); 
		return false;
		};	 	
		</script>
</div>	

	
<!-- https://www.facebook.com/dialog/pagetab?app_id=274414319389630&redirect_uri=https://www.facebook.com -->
















