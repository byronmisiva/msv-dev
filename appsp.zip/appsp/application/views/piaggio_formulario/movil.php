<!DOCTYPE html>
<html>
<head>	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />	
	<link href="<?php echo base_url('css/piaggio_formulario/piaggio_formulario.css?refresh='.rand(10, 1000))?>" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Didact+Gothic:400" rel="stylesheet" type="text/css">
	<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
	<script type="text/javascript" src="<?=base_url('js/general/validate.js?refresh=198926546568797915')?>"></script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>	
	<style>
	.texto{
		font-family: Arial;
		font-size: 16px;
		color:#ffffff;
		margin:24% 5% 2% auto;
		width: 90%; 
		max-width: 90%;
	}
	body{
	font-family: Arial;
	}
	</style>
	
		
</head>
<body style="width: 100%;background: #385285;height: auto;margin: 0;">	
	<div id="content" class="container" style="position:relative;margin:0 auto;width: 100%;background-image: url('<?php echo $fondo?>');background-position: center 10px;;background-repeat: no-repeat;background-size:90%;height:auto;  ">
		<div class="fondo" style="height:auto;background-repeat:no-repeat;width:100%;">
		<div class="texto" >
			Adquiere una Vespa hasta el 15 de abril y participa en el sorteo de un viaje todo pagado a La Toscana, Italia.
			¿Siempre soñaste con una? Completa este formulario y nos podremos en contacto contigo para ayudarte en todo lo que necesitas.	
		</div>
	<div class="registro" style="margin: 0% auto;width:90% ;height:94%;position: inherit;background-color: rgba(255,255,255,0.2);hepadding-top: 5px;padding-left: 10px;-webkit-border-radius: 10px;
-moz-border-radius: 10px;
border-radius: 10px;" >
		<form id ="register" method="post" role="form" class="form-horizontal formulario" action="<?php echo base_url('piaggio_formulario/register_movil')?>">
		<table width="95%">
			<tr>
				<td style="color:#fff;">Nombre</td>
				<td><input type="text" id="nombre"	name="nombre" placeholder="" value="" style="border:1px solid #fff;height:30px;width:95%;font-size:14px;margin-top:5px;" /></td>
			</tr>
			<tr>
				<td style="color:#fff;">	Ciudad</td>
				<td><input type="text"  id="ciudad" name="ciudad" placeholder="" value="" style="border:1px solid #fff;height:30px;width:95%;font-size:14px;margin-top:5px;" /></td>
			</tr>
			<tr>
				<td style="color:#fff;">	Fecha Nac.</td>
				<td>	<input type="date" id="fecha" name="fecha" placeholder="" value="" style="border:1px solid #fff;height:30px;width:95%;font-size:14px;margin-top:5px;" /></td>
			</tr>
			<tr>
				<td style="color:#fff;">Teléfono </td>
				<td><input type="tel" id="telefono" name="telefono" placeholder="" value="" style="border:1px solid #fff;height:30px;width:95%;font-size:14px;margin-top:5px;" /></td>
			</tr>
			<tr>
				<td style="color:#fff;">E-mail</td>
				<td><input type="email" id="mail" name="mail" placeholder="" value="" style="argin-left:13%;border:1px solid #fff;height:30px;width:95%;font-size:14px;margin-top:5px;" /></td>
			</tr>
			<tr>
				<td colspan="2" style="text-align: center;">
					<input id="submit" name="submit" type="submit" value="" class="btn-sumbit" style="cursor:pointer;width:120px;height:35px;display: inline-block; margin-top: 12px;background-image: url('<?php echo $boton?>');background-size:100%; "></td>
				
			</tr>
		</table>	
			

			<input type="hidden" name="user" id="user" value='movil'>
			<input type="hidden" name="fb_page" id="fb_page" value=''>
			
		</form>
		
		
	</div>
	
</div>
	
	
	</div>
	<div id="condiciones">
		<!-- <strong>T&eacute;rminos y Condiciones:</strong><br/> 
		<?=$condiciones;?> -->
	</div>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
		
	<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">	
	<script type="text/javascript" src="<?=base_url('js/general/library_facebook.js?refresh=19898797915')?>"></script>
	<script type="text/javascript" src="<?=base_url('js/general/validate.js?refresh=198926546568797915')?>"></script>	

	 <script type="text/javascript">
		
		
	var rules = [ 
				   { name: 'nombre', display: 'nombre', rules: 'required'},
	               { name: 'ciudad', display: 'ciudad', rules: 'required'},
	               { name: 'fecha', display: 'fecha', rules: 'required'},
	               { name: 'telefono', display: 'telefono', rules: 'required|min_length[10]'},	               
	               { name: 'mail', display: 'mail', rules: 'required|valid_email'}	               
	            ];    
	
	var validator = new FormValidator('register',rules, function(errors, event) {		
		 if (errors.length > 0) {
		        var errorString = '';  
		        alert("Verifica que la información ingresada sea la correcta.");  
		    }else{
		    	enviarForma('<?=base_url()?>','register'); 		    			    	
			    }
		});
	
	
		function enviarForma(accion,forma){						
		$.ajax({  
			  type: "POST",  
			  url: accion+"piaggio_formulario/register_movil",  
			  data: $('#'+forma).serialize(),
			  success: function( response ) {
				  if (response=="1"){					  
					$('#submit').hide();
				    $('body').load(accion+"piaggio_formulario/gracias_movil");
				  }
	    		} 
			}); 
		return false;
		};	 	
		</script>
</body>
</html>

	

















