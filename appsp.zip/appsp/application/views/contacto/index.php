<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<title>Formulario Contacto</title>
<!-- Bootstrap core CSS -->
<link href="<?php echo base_url()?>css/bootstrap.min.css" rel="stylesheet" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="<?php echo base_url('js/general/validate.js')?>"></script>
<style>
body{
	background-color: #F3F0D8;
}

.cuerpo{
margin-top: 35px;
}
.normal{
	display: inline-block;
}

.smart{
	display: none;
}

input{
	background: transparent;
	border: none;
}

#btn-enviar{
	width: 77px;
	height: 26px;
	background-image: url('imagenes/formulario/ENVIAR.png');
	background-repeat: no-repeat;
	float: right;
}

.input{	
    color: #000000;
    float: none;
    font-size: 14px;
    height: 22px;
    line-height: 22px;
    margin-left: 90px;
    width: 239px;
    padding-left: 15px;
}

/* Small devices (tablets, 768px and up) */
@media screen and (max-device-width: 600px){
	.col-sm-12{
		text-align: center;
	}
	
	.col-xs-12{
	text-align: center;
	}
	.normal{
		display: none;
	}
	
	.smart{
		display: inline-block;
	}
}

</style>
</head>
<body>
	<div class="container cuerpo">		
		<div class="row">
		<div class="col-md-3 col-sm-1 col-xs-12"></div>
			<div class="col-md-3 col-sm-4 col-xs-12">
				<img src="<?php echo base_url().'imagenes/formulario/logoproyecto.png'?>" />
			</div>
			<div class="col-md-6 col-sm-5 col-xs-12" style="height: 170px;">
				<div style="position:absolute;left:0;top:0;">
					<img src="<?php echo base_url().'imagenes/formulario/formulario.png'?>" />
				</div>
				<div style="position:absolute;left:0;top:0;">
				<form id="forma_registro">
					<div class="input" style="margin-top: 5px;">
						<input type="text" id="nombre" name="nombre" />
					</div>
					<div class="input" style=" margin-top: 7px;"> 
						<input type="text" id="apellido" name="apellido" />
					</div>
					<div class="input" style="margin-top: 14px;">
						<input type="text" id="telefono" name="telefono" />
					</div>
					<div class="input" style=" margin-top: 8px;">
						<input type="text" id="mail" name="mail" />
					</div>
					<div class="input" style="margin-top: 8px;">
						<input type="submit" id="btn-enviar" value="" />
					</div>
				
				</form>
				</div>
			</div>
		</div>
		
		<div class="row">		
			<div class="col-md-12 col-xs-12" style="text-align: center;">
				<img src="<?php echo base_url().'imagenes/formulario/texto1.png'?>"  class="normal" class="img-responsive" />
				<img src="<?php echo base_url().'imagenes/formulario/texto1.1.png'?>" class="smart" class="img-responsive" />
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-3 col-sm-1 col-xs-12"></div>
			<div class="col-md-3 col-sm-5 col-xs-12">
				<div class="row">
					<div class="col-md-12">
						<img src="<?php echo base_url().'imagenes/formulario/mapa.png'?>" />
					</div>
					<div class="col-md-12">
							<img src="<?php echo base_url().'imagenes/formulario/visitanos.png'?>" />
					</div>					
				</div>
			</div>
			<div class="col-md-6 col-sm-5 col-xs-12">
					<div class="row">
						<div class="col-md-12" style="margin-top:50px;;">
							<img src="<?php echo base_url().'imagenes/formulario/texto2.png'?>" />
						</div>
						<div class="col-md-12" style="margin-top:100px;;">
							<img src="<?php echo base_url().'imagenes/formulario/distrubucion.png'?>" />
						</div>
					</div>
			</div>
		</div>
				
	</div>	
	<script src="<?php echo base_url()?>js/bootstrap.min.js"></script>
	<script type="text/javascript">	
	var rules = [ 
				   { name: 'nombre', display: 'nombre', rules: 'required'},
	               { name: 'apellido', display: 'apellido', rules: 'required'},
	               { name: 'mail', display: 'mail', rules: 'required|valid_email'},	               
	               { name: 'telefono', display: 'telefono', rules: 'required|min_length[7]'}	               	               
	            ];    
	
	var validator = new FormValidator('forma_registro',rules, function(errors, event) {		
		 if (errors.length > 0) {
		        var errorString = '';	
		        alert("Revisar que los campos estén correctamente ingresados");
		    }else{
		    	$("#btn-enviar").hide();
		    	enviarForma('<?=base_url()?>','forma_registro');
		    } 	    	
		});
	
		function enviarForma(accion,forma){						
		$.ajax({  
			  type: "POST",  
			  url: accion+"contacto/envio_mail",  
			  data: $('#'+forma).serialize(),
			  success: function( response ) {				  				  
					  if(response=="1")
						alert("Registro realizado Correctamente");
					  $("#btn-enviar").show();
					  $("#nombre").val("");
					  $("#apellido").val("");
					  $("#mail").val("");
					  $("#telefono").val("");
	    		} 
			}); 
		return false;
		};	 	
		</script>
</body>
</html>
