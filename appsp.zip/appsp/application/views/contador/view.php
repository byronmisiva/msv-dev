
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <title>Countdown that doesn't sucks</title>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="js/contador-atras/jquery.countdown.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript">
    var d = new Date();
    var horaAactual = d.getHours();
    var minutoAactual = d.getMinutes();
    var hora = 20 - horaAactual;
    if( hora < 10){
    	 hora = "0"+hora;
    }
    
    var minutos = 60 - minutoAactual;
    if (minutos < 10){
    	minutos = "0"+minutos;
    } 
    	
    
      $(function(){
        $('#counter').countdown({
          image: '<?php echo base_url()?>imagenes/digits.png',
          startTime: hora+":"+minutos+":00"
        })        
      });
    </script>
    <style type="text/css">
      br { clear: both; }
      .cntSeparator {
        color: #000;
	    font-size: 20px;
	    margin: 0;
      }
      .desc { margin: 7px 3px; width: 300px;}
      .desc div {
        float: left;
        font-family: Arial;
        width: 86px;
        margin-right: 0px;
        font-size: 13px;
        font-weight: bold;
        color: #000;
        text-align: center;
        color:#fff;
      }
      
      body{
      background: #000;
      }
      
      #cnt_6, #cnt_7{
      display: none;
      }
    </style>
  </head>
<body>
  <div id="counter"></div>
  <div class="desc">    
    <div>Horas</div>
    <div>Minutos</div>    
  </div>
  
  
</body>
</html>
