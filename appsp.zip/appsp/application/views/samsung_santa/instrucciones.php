<div class="instrucciones">
	 <a href="<?php echo base_url('samsung_santa/lista')?>" class="btn-empezar"></a>
</div>
<script type="text/javascript">
	Tab.setEvent();
</script>