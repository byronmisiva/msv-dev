var Tab =(function() {
	
	var register = function() {
		$( "#register" ).submit(function( event ) {	
			event.preventDefault();
			$.ajax({					
				type: this.method,
				url: this.action,
				data: $(this).serialize(),
				success: function( response ) {			    					
					$("#content").html( response );		
				}
			});	
		});
	};
	
	var showErrors = function( obj ) {
		$( '#' + obj ).css( { 'color' : '#FF0000' } );
	};
	
	var setEventPremios = function() {
		$('a.premio').click( function(event){			
			event.preventDefault();
			$(this).addClass('active');
			romeveClass( this, 'premio', 'active' );							
		});
	};
	
	var setEventAccessories = function( active ) {
		$('a.accessories').click( function(event){			
			event.preventDefault();
			$(this).addClass(active);
			romeveClass( this, 'accessories', active );
		});		
	};
	
	var romeveClass = function( obj, other, active) {
		items = $('a.' + other);
		for ( var i = 0; i < items.length; i++) {
			if( items[i] != obj){
				$( items[i] ).removeClass(active);
			}
		}	
	};

	
	var setEvent = function() {
		$('a.btn-empezar').click( function(event){
			event.preventDefault();
			$.ajax({		
				type : "post",
				url: this.href,
				data : { 'user' : JSON.stringify( LibraryFacebook.getUserFbData() ), 'fb_page' : JSON.stringify( LibraryFacebook.getSignedRequest() ) },
				success: function( response ) {		    					
					$("#content").html( response );	
				}
			});				
		});
	};
	
	return { 
		register: register,
		showErrors : showErrors,
		setEventPremios : setEventPremios,
		setEventAccessories : setEventAccessories,
		setEvent : setEvent
		};	
	
})();