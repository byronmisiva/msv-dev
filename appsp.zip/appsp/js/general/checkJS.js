function check() {
	console.debug("DEBES ACTIVAR JAVASCRIPT");	
};