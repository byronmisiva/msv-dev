$(document).ready(function () {
	var selector1, bombillos, ArraySelectedFriends = [], friend_selected, logActivity, callbackFriendSelected, callbackFriendUnselected, callbackMaxSelection, callbackSubmit,
		updatePicture,
		BaseUrl = document.location.protocol + "//appss.misiva.com.ec/";		
	
	$.ajax({
		type: "GET",
		url: BaseUrl + "samsung_palco/init_selected_friend",			
		success: function(data) {
			SelectedFriends = $.parseJSON(data);
			$.each( SelectedFriends, function( key, value ) {				
				ArraySelectedFriends[key]=value;
			});	
			selector1.setDisabledFriendIds( ArraySelectedFriends );
			setEventosAmigos();
		}
	});	
	
	// When a friend is selected, log their name and ID
	callbackFriendSelected = function(friendId) {
			
	};

	// When a friend is deselected, log their name and ID
	callbackFriendUnselected = function(friendId) {
		
	};

	// When the maximum selection is reached, log a message
	callbackMaxSelection = function() {
		//logActivity('Selected the maximum number of friends');
	};

	// When the user clicks OK, log a message
	callbackSubmit = function( selectedFriendIds ) {
		var friend;
		friend =  ($.inArray(selectedFriendIds[0], ArraySelectedFriends) >=0 ) ?  null : TDFriendSelector.getFriendById(selectedFriendIds);				
		if ( friend != null ){			
			var obj = {
					method: 'feed',
					link: 'https://apps.facebook.com/samsung_palco/index/',
					picture: 'https://appss.misiva.com.ec/imagenes/samsung_palco/75x75.jpg?fbrefresh=123456',
					name: 'Palco Samsung',
					caption: '&#161;Vive los partidos de Copa Libertadores!',
					description: 'Te han elegido para asistir al Palco Samsung, t&uacute; tambi&eacute;n puedes participar ingresando aqu&iacute; y ganar entradas para el siguiente partido de Copa Libertadores. Dale click.',
					to : friend.id						
			};
			function callback(response) {				
				if ( response != undefined ){
					ArraySelectedFriends[ friend_selected ] = friend.id;					
					selector1.setDisabledFriendIds(ArraySelectedFriends);
					updatePicture( friend );
					friend.posicion = friend_selected;	
			    	$.ajax({
			    		type: "GET",
			    		url: BaseUrl + "samsung_palco/registrar_amigo",
			    		data: { 'data' :  friend },
			    		success: function(data) {
			    			if( parseInt(data) >= 5 ){
			    				var obj = {
			    						method: 'feed',
			    						link: 'https://apps.facebook.com/samsung_palco/index/',
			    						picture: 'https://appss.misiva.com.ec/imagenes/samsung_palco/75x75.jpg?fbrefresh=123456',
			    						name: 'Palco Samsung',
			    						caption: '&#161;M&aacute;s cerca de asistir a los partidos de Copa Libertadores!',
			    						description: 'Estoy participando en el sorteo de entradas al siguiente partido de Copa Libertadores que se jugar&aacute; en Ecuador, participa ingresando aqu&iacute;.'			    											
			    				};
			    				FB.ui(obj, null);				
			    				window.location = BaseUrl+'samsung_palco/vista_completo';
			    			}
			    		}
					});	
				}					
			}
			FB.ui(obj, callback);							
		}
	};	
	
	updatePicture = function( friend ){			
		$("#foto_"+friend_selected ).html("<img src='//graph.facebook.com/" + friend.id + "/picture?type=square' width='50' height='50' alt='" + friend.name + "'  />");
	};
	
	unbindEvents = function() {		
		bombillos = $("div.bombillo");		 
		$.each( bombillos, function( key, value ) {
			$('#'+value.id).unbind('click');
		});		
	};	
	
	callbackShowFriendSelector = function ( id ) {
		friend_selected = id;
	};

	// Initialise the Friend Selector with options that will apply to all instances
	TDFriendSelector.init({backgroundSelector       : '.TDFriendSelectorBackgroud'});
	//TDFriendSelector.init();

	// Create some Friend Selector instances
	selector1 = TDFriendSelector.newInstance({
		callbackFriendSelected   : callbackFriendSelected,
		callbackFriendUnselected : callbackFriendUnselected,
		callbackMaxSelection     : callbackMaxSelection,
		callbackSubmit           : callbackSubmit,
		maxSelection             : 1,
		friendsPerPage           : 5,
		autoDeselection          : true 
	});

	/*FB.getLoginStatus(function(response) {
		if (response.authResponse) {
			$("#login-status").html("Logged in");
		} else {
			$("#login-status").html("Not logged in");
		}
	})*/;
	
	updatePicture = function( friend ){			
		$("#foto_"+friend_selected ).html("<img src='//graph.facebook.com/" + friend.id + "/picture?type=square' width='50' height='50' alt='" + friend.name + "'  />");
	};
	
	//A�ado los eventos a los div q quiero
	setEventosAmigos = function(){
		amigos = $("div.amigo");		
		$.each( amigos, function( key, value ) {			
			$('#'+value.id).click(function (e) {	
				if( key <= 3 ){
					e.preventDefault();					
					selector1.showFriendSelector( callbackShowFriendSelector( ( key + 1 ) ) );
				}
			}); 
		});
	};	

	logActivity = function (message) {
		$("#results").append('<div>' + new Date() + ' - ' + message + '</div>');
		//concole.debug( message );
	};
});
