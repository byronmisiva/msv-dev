var Tab =(function() {
	
	var register = function() {
		$( "#register" ).submit(function( event ) {	
			event.preventDefault();
			$.ajax({					
				type: this.method,
				url: this.action,
				data: $(this).serialize(),
				success: function( response ) {			    					
					$("#content").html( response );		
				}
			});	
		});
	};
	
	var showErrors = function( obj ) {
		$( '#' + obj ).css( { 'color' : '#FF0000' } );
	};
	
	var romeveClass = function( obj, other, active) {
		items = $('a.' + other);
		for ( var i = 0; i < items.length; i++) {
			if( items[i] != obj){
				$( items[i] ).removeClass(active);
			}
		}	
	};

	
	return { 
		register: register,		
		setEvent : setEvent
		};	
	
})();